
<div class="portada">
    <h1>Portafolio Académico – Teoría de la Programación</h1>
    <p>
        Institución: [Tu Institución] <br>
        Carrera: [Tu Carrera] <br>
        Asignatura: Teoría de la Programación <br>
        Ciclo: [X] <br>
        Período Académico: [YYYY] <br>
        Docente: [Nombre Docente] <br>
        Estudiante: Yimmy Angulo
    </p>
</div>

<div class="card">
    <h2>📌 Navegación</h2>
    <p>Accede rápidamente a las secciones de tu portafolio:</p>
    <a class="button" href="unidad1/contenidos.md">Contenidos de la Unidad 1</a>
    <a class="button" href="unidad1/tareas.md">Tareas Entregadas</a>
    <a class="button" href="unidad1/evaluaciones.md">Evaluaciones Tomadas</a>
    <a class="button" href="bibliografia.md">Bibliografía</a>
    <a class="button" href="declaracion_IA.md">Declaración de IA</a>
</div>
